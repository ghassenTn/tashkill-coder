from flask import Flask, render_template, request, redirect, url_for, jsonify
from datetime import datetime, timedelta
import os
from extensions import db

def create_app():
    app = Flask(__name__)

    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(app.root_path, 'database.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)

    from models import Task

    with app.app_context():
        db.create_all()

    @app.route('/')
    def index():
        status_filter = request.args.get('status', 'all')
        
        query = Task.query
        page_title = "All Tasks"

        if status_filter == 'pending':
            query = query.filter_by(status='pending')
            page_title = "Pending Tasks"
        elif status_filter == 'completed':
            query = query.filter_by(status='completed')
            page_title = "Completed Tasks"
        # If status_filter is 'all' or invalid, show all tasks

        tasks = query.order_by(Task.created_at.desc()).all()
        return render_template('index.html', tasks=tasks, page_title=page_title, current_status=status_filter)

    @app.route('/add', methods=['POST'])
    def add_task():
        title = request.form.get('title')
        if title:
            new_task = Task(title=title)
            db.session.add(new_task)
            db.session.commit()
        return redirect(url_for('index'))

    @app.route('/complete/<int:task_id>', methods=['POST'])
    def complete_task(task_id):
        task = Task.query.get_or_404(task_id)
        task.status = 'completed'
        db.session.commit()
        return redirect(url_for('index'))

    @app.route('/incomplete/<int:task_id>', methods=['POST'])
    def incomplete_task(task_id):
        task = Task.query.get_or_404(task_id)
        task.status = 'pending'
        db.session.commit()
        return redirect(url_for('index'))

    @app.route('/delete/<int:task_id>', methods=['POST'])
    def delete_task(task_id):
        task = Task.query.get_or_404(task_id)
        db.session.delete(task)
        db.session.commit()
        return redirect(url_for('index'))

    @app.route('/data/tasks_summary')
    def tasks_summary():
        with app.app_context():
            pending_count = Task.query.filter_by(status='pending').count()
            completed_count = Task.query.filter_by(status='completed').count()

            # Data for Line Chart (Tasks created per day for last 7 days)
            daily_tasks_data = {}
            today = datetime.utcnow().date()
            for i in range(7):
                date = today - timedelta(days=6 - i)
                daily_tasks_data[date.strftime('%Y-%m-%d')] = 0

            tasks_last_7_days = Task.query.filter(Task.created_at >= (today - timedelta(days=6))).all()
            for task in tasks_last_7_days:
                task_date_str = task.created_at.date().strftime('%Y-%m-%d')
                if task_date_str in daily_tasks_data:
                    daily_tasks_data[task_date_str] += 1
            
            daily_labels = list(daily_tasks_data.keys())
            daily_values = list(daily_tasks_data.values())

            # Data for Radar Chart (Tasks created per day of the week)
            # Monday is 0, Sunday is 6
            days_of_week = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            tasks_by_weekday = {day: 0 for day in days_of_week}
            
            all_tasks = Task.query.all()
            for task in all_tasks:
                weekday_index = task.created_at.weekday() # Monday is 0
                tasks_by_weekday[days_of_week[weekday_index]] += 1
            
            weekday_labels = list(tasks_by_weekday.keys())
            weekday_values = list(tasks_by_weekday.values())

            return jsonify({
                'barChartData': {
                    'labels': ['Pending', 'Completed'],
                    'data': [pending_count, completed_count]
                },
                'lineChartData': {
                    'labels': daily_labels,
                    'data': daily_values
                },
                'radarChartData': {
                    'labels': weekday_labels,
                    'data': weekday_values
                }
            })

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
