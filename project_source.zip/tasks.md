# To-Do App Development Tasks

## Backlog

### Project Setup and Core

*   [x] 1. Initialize project directory `todo-app/`.
*   [x] 2. Create `app.py` for the main Flask application.
*   [x] 3. Create `models.py` for database models.
*   [x] 4. Create `templates/` directory.
*   [x] 5. Create `static/` directory.
*   [x] 6. (Optional) Create `static/style.css` for basic styling.
*   [x] 7. Install Flask and SQLAlchemy.

### Database Integration (NFR5, NFR7)

*   [x] 8. Configure Flask application to use SQLite database (e.g., `database.db`). (Depends on: 2, 3)
*   [x] 9. Define `Task` model in `models.py` with `id`, `title`, `status` (pending/completed), and `created_at` fields using SQLAlchemy. (Depends on: 3, 7)
*   [x] 10. Implement database initialization logic in `app.py` to create tables if they don't exist. (Depends on: 2, 9)

### Frontend - Basic Structure (NFR6)

*   [x] 11. Create `templates/index.html` with a basic HTML structure. (Depends on: 4)
*   [x] 12. Link `static/style.css` in `index.html`. (Depends on: 6, 11)

### Functional Requirement Implementation - Core (FR1, FR2)

*   [x] 13. Implement `GET /` route in `app.py` to fetch all tasks from the database (FR1). (Depends on: 2, 10)
*   [x] 14. Pass fetched tasks to `index.html` template for rendering. (Depends on: 13)
*   [x] 15. Display tasks in `index.html` including title and status. (Depends on: 11, 14)
*   [x] 16. Implement `POST /add` route in `app.py` to handle new task creation (FR2). (Depends on: 2, 10)
*   [x] 17. Add a form in `index.html` to allow users to input a new task title. (Depends on: 11, 15)
*   [x] 18. Save new tasks to the database with a default "pending" status. (Depends on: 16)
*   [x] 19. Redirect to `GET /` after adding a new task. (Depends on: 16)

### Functional Requirement Implementation - Updates and Deletion (FR3, FR4, FR5)

*   [x] 20. Implement `POST /complete/<int:task_id>` route to mark a task as complete (FR3). (Depends on: 2, 10)
*   [x] 21. Add a button/checkbox in `index.html` next to each task to mark it as complete. (Depends on: 15)
*   [x] 22. Implement `POST /incomplete/<int:task_id>` route to mark a task as incomplete (FR4). (Depends on: 2, 10)
*   [x] 23. Add a button/checkbox in `index.html` next to each *completed* task to mark it as incomplete. (Depends on: 15)
*   [x] 24. Implement `POST /delete/<int:task_id>` route to delete a task (FR5). (Depends on: 2, 10)
*   [x] 25. Add a delete button in `index.html` next to each task. (Depends on: 15)
*   [x] 26. Ensure redirects to `GET /` after task status updates or deletion. (Depends on: 20, 22, 24)

### Refinement and Non-Functional Compliance (NFR1, NFR3, NFR8, NFR9, NFR10)

*   [x] 27. Add basic error handling for database operations and invalid requests. (Depends on: 2)
*   [x] 28. Refactor `app.py` and `models.py` for code readability and modularity (NFR9, NFR10).
*   [x] 29. Test all functional requirements (FR1-FR5) to ensure correctness and responsiveness (NFR1).
*   [x] 30. Review UI/UX for intuitiveness (NFR3).
*   [x] 31. (Optional) Add minimal CSS to improve the appearance of `index.html` (NFR6).