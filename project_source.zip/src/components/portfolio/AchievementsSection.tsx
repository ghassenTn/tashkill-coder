import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Star, Target, Zap, Github } from "lucide-react";

const AchievementsSection = () => {
  const achievements = [
    {
      id: "pull-shark",
      title: "Pull Shark Achievement",
      description: "Successfully completed a challenging pull request milestone",
      icon: <Trophy className="w-8 h-8 text-yellow-500" />,
      date: "Recent",
      category: "Development"
    },
    {
      id: "yolo",
      title: "YOLO Achievement",
      description: "Implemented advanced computer vision technology",
      icon: <Zap className="w-8 h-8 text-purple-500" />,
      date: "Recent",
      category: "AI/ML"
    }
  ];

  const stats = [
    { label: "Public Repositories", value: "18", icon: <Github className="w-6 h-6 text-blue-500" />, change: "+2 this month" },
    { label: "Total Stars", value: "4", icon: <Star className="w-6 h-6 text-yellow-500" />, change: "+4 this month" },
    { label: "Pull Requests", value: "50+", icon: <Target className="w-6 h-6 text-green-500" />, change: "Active contributor" },
    { label: "Contributions", value: "200+", icon: <Zap className="w-6 h-6 text-purple-500" />, change: "Last 12 months" }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Achievements & Stats
            </h2>
            <p className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto">
              Recognition of contributions and milestones in open-source development
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {stats.map((stat, index) => (
              <Card key={index} className="border-0 shadow-lg bg-white dark:bg-slate-900 hover:shadow-xl transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="flex justify-center mb-4">
                    {stat.icon}
                  </div>
                  <div className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-2">
                    {stat.value}
                  </div>
                  <div className="text-sm font-medium text-slate-600 dark:text-slate-400 mb-1">
                    {stat.label}
                  </div>
                  <div className="text-xs text-green-600 dark:text-green-400 font-medium">
                    {stat.change}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Achievements */}
          <div className="space-y-8">
            <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100 text-center">
              Recent Achievements
            </h3>
            
            <div className="grid md:grid-cols-2 gap-8">
              {achievements.map((achievement, index) => (
                <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 bg-white dark:bg-slate-900">
                  <CardContent className="p-8">
                    <div className="flex items-start gap-6">
                      <div className="flex-shrink-0">
                        {achievement.icon}
                      </div>
                      <div className="flex-1 space-y-3">
                        <div className="flex items-center gap-3">
                          <h4 className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                            {achievement.title}
                          </h4>
                          <Badge variant="secondary" className="text-xs">
                            {achievement.category}
                          </Badge>
                        </div>
                        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                          {achievement.description}
                        </p>
                        <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                          {achievement.date}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Additional Recognition */}
          <div className="mt-16 text-center">
            <Card className="border-0 shadow-lg bg-gradient-to-r from-blue-600 to-purple-600 text-white">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold mb-2">Continuous Learner</h3>
                <p className="text-blue-100 mb-4">
                  Always exploring new technologies and contributing to open-source projects
                </p>
                <div className="flex justify-center gap-4">
                  <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                    Python Expert
                  </Badge>
                  <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                    AI/ML Enthusiast
                  </Badge>
                  <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                    Open Source Contributor
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AchievementsSection;