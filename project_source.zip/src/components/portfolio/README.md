# Portfolio Components

This directory contains all the components for Ghassen Saidi's modern portfolio website built with React, TypeScript, and Tailwind CSS.

## Components

### 🏠 HeroSection
- **Location**: `./HeroSection.tsx`
- **Description**: Eye-catching hero section with gradient background, profile card, and call-to-action buttons
- **Features**:
  - Gradient background with decorative elements
  - Profile avatar with fallback
  - Social information display
  - Responsive design
  - Dark mode support

### 🛠️ SkillsSection
- **Location**: `./SkillsSection.tsx`
- **Description**: Technical skills showcase with categorized expertise levels
- **Features**:
  - Skills categories with badges
  - Expertise level progress bars
  - Clean card-based layout
  - Responsive grid system

### 📁 ProjectsSection
- **Location**: `./ProjectsSection.tsx`
- **Description**: GitHub projects display with detailed information
- **Features**:
  - Project cards with metadata
  - Star counts and language indicators
  - Topic tags
  - GitHub and demo links
  - Hover animations

### 🏆 AchievementsSection
- **Location**: `./AchievementsSection.tsx`
- **Description**: Achievement showcase with statistics and milestones
- **Features**:
  - GitHub statistics cards
  - Achievement badges
  - Progress indicators
  - Recognition highlights

### 📧 ContactSection
- **Location**: `./ContactSection.tsx`
- **Description**: Contact form and social media links
- **Features**:
  - Interactive contact form
  - Social media links
  - Skills showcase
  - Contact information display

### 🧭 Navigation
- **Location**: `./Navigation.tsx`
- **Description**: Responsive navigation header with mobile support
- **Features**:
  - Desktop and mobile navigation
  - Smooth scrolling
  - Mobile hamburger menu
  - Social links

### 📄 Footer
- **Location**: `./Footer.tsx`
- **Description**: Comprehensive footer with links and contact info
- **Features**:
  - Brand information
  - Quick navigation links
  - Social media links
  - Copyright information

## Usage

All components are designed to work together in the main `Index.tsx` page. Simply import and use them as needed:

```tsx
import HeroSection from "@/components/portfolio/HeroSection";
import SkillsSection from "@/components/portfolio/SkillsSection";
// ... other components

export default function Index() {
  return (
    <div>
      <Navigation />
      <HeroSection />
      <SkillsSection />
      {/* ... other sections */}
      <Footer />
    </div>
  );
}
```

## Styling

All components use:
- **Tailwind CSS** for styling
- **shadcn/ui** components for UI elements
- **Dark mode** support
- **Responsive design** principles
- **Modern animations** and transitions

## Customization

To customize:
1. Update text content in individual components
2. Modify colors in `tailwind.config.ts`
3. Adjust spacing and layout using Tailwind classes
4. Add or remove components as needed

## Dependencies

- React 18+
- TypeScript
- Tailwind CSS
- shadcn/ui components
- Lucide React icons
- React Router (for navigation)