import { Github, ExternalLink, Mail, MapPin, Twitter } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { name: "GitHub", url: "https://github.com/ghassenTn", icon: <Github className="w-4 h-4" /> },
    { name: "Twitter", url: "https://twitter.com/ghassenTn", icon: <Twitter className="w-4 h-4" /> },
    { name: "ORCID", url: "https://orcid.org/0009-0007-4728-6033", icon: <ExternalLink className="w-4 h-4" /> },
    { name: "Kaggle", url: "https://www.kaggle.com/patchgc", icon: <ExternalLink className="w-4 h-4" /> },
  ];

  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Brand */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">GS</span>
                </div>
                <span className="text-xl font-bold text-white">Ghassen Saidi</span>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed">
                Full Stack Developer & AI Enthusiast dedicated to building innovative solutions and contributing to open-source projects.
              </p>
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <MapPin className="w-4 h-4" />
                Sfax, Tunisia
              </div>
            </div>

            {/* Quick Links */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#home" className="text-slate-400 hover:text-white transition-colors">Home</a></li>
                <li><a href="#skills" className="text-slate-400 hover:text-white transition-colors">Skills</a></li>
                <li><a href="#projects" className="text-slate-400 hover:text-white transition-colors">Projects</a></li>
                <li><a href="#achievements" className="text-slate-400 hover:text-white transition-colors">Achievements</a></li>
                <li><a href="#contact" className="text-slate-400 hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>

            {/* Social Links */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider">Connect</h3>
              <div className="flex flex-wrap gap-3">
                {socialLinks.map((link, index) => (
                  <a
                    key={index}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors text-sm"
                  >
                    {link.icon}
                    <span>{link.name}</span>
                  </a>
                ))}
              </div>
            </div>

            {/* Contact */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider">Contact</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-2 text-slate-400">
                  <Mail className="w-4 h-4" />
                  <span>ghassen.qi.pi.ki.li.mi.ni.ji</span>
                </div>
                <p className="text-slate-400 text-sm">
                  Feel free to reach out for collaborations, questions, or just to say hello!
                </p>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-800 mt-12 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-sm text-slate-400">
                © {currentYear} Ghassen Saidi. All rights reserved.
              </p>
              <div className="flex items-center gap-4 text-sm text-slate-400">
                <span>Designed with ❤️ using React & Tailwind CSS</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;