import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Github, ExternalLink, MapPin, Clock } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 bg-grid-white/[0.05] bg-[length:20px_20px]" />
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left side - Hero content */}
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge variant="secondary" className="inline-flex items-center gap-2 px-3 py-1">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  Active Developer
                </Badge>
                
                <h1 className="text-5xl lg:text-7xl font-bold bg-gradient-to-r from-slate-900 to-slate-600 dark:from-slate-100 dark:to-slate-400 bg-clip-text text-transparent leading-tight">
                  Ghassen Saidi
                </h1>
                
                <p className="text-xl lg:text-2xl text-slate-600 dark:text-slate-300">
                  Full Stack Developer & AI Enthusiast
                </p>
                
                <p className="text-lg text-slate-500 dark:text-slate-400 max-w-2xl leading-relaxed">
                  We are a grassroots movement dedicated to raising awareness about the Palestinian cause and advocating for the rights of the Palestinian people.
                </p>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <Button size="lg" className="gap-2">
                  <Github className="w-4 h-4" />
                  View GitHub
                </Button>
                <Button size="lg" variant="outline" className="gap-2">
                  <ExternalLink className="w-4 h-4" />
                  View Profile
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-6 text-sm text-slate-600 dark:text-slate-400">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Sfax, Tunisia
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  21:42 UTC -12:00
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full" />
                  4 followers · 6 following
                </div>
              </div>
            </div>
            
            {/* Right side - Profile card */}
            <div className="relative">
              <Card className="relative overflow-hidden border-0 shadow-2xl bg-white/80 backdrop-blur-lg dark:bg-slate-900/80">
                <CardContent className="p-8">
                  <div className="flex flex-col items-center space-y-6">
                    <Avatar className="w-32 h-32 ring-4 ring-blue-500/20 dark:ring-blue-400/20">
                      <AvatarImage src="https://avatars.githubusercontent.com/u/placeholder" />
                      <AvatarFallback className="text-3xl font-bold bg-gradient-to-br from-blue-600 to-purple-600 text-white">
                        GS
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="text-center space-y-2">
                      <h3 className="text-2xl font-bold">Ghassen Saidi</h3>
                      <p className="text-slate-600 dark:text-slate-300">@ghassenTn</p>
                      <p className="text-sm text-slate-500 dark:text-slate-400">he/him</p>
                    </div>
                    
                    <div className="flex gap-4">
                      <Badge variant="secondary">Python</Badge>
                      <Badge variant="secondary">TypeScript</Badge>
                      <Badge variant="secondary">JavaScript</Badge>
                    </div>
                    
                    <div className="flex gap-4 text-sm text-slate-600 dark:text-slate-400">
                      <div className="text-center">
                        <div className="font-bold text-lg">4</div>
                        <div>Followers</div>
                      </div>
                      <div className="text-center">
                        <div className="font-bold text-lg">6</div>
                        <div>Following</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;