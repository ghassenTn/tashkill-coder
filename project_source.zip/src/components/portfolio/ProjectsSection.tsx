import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Github, Calendar, Star } from "lucide-react";

interface Project {
  name: string;
  description: string;
  language: string;
  stars: number;
  updated: string;
  topics: string[];
  url: string;
  githubUrl: string;
  isPrivate?: boolean;
}

const ProjectsSection = () => {
  const projects: Project[] = [
    {
      name: "tashkill-coder",
      description: "Public Python repository updated frequently",
      language: "Python",
      stars: 0,
      updated: "3 days ago",
      topics: ["Python", "Development"],
      url: "#",
      githubUrl: "https://github.com/ghassenTn/tashkill-coder"
    },
    {
      name: "fennec",
      description: "Python repository with various tools and utilities",
      language: "Python",
      stars: 0,
      updated: "4 days ago",
      topics: ["Python", "Utilities"],
      url: "#",
      githubUrl: "https://github.com/ghassenTn/fennec"
    },
    {
      name: "ChartForgeTK",
      description: "Bring your Tkinter apps to life 🔥",
      language: "Python",
      stars: 4,
      updated: "1 month ago",
      topics: ["Python", "Tkinter", "GUI"],
      url: "https://github.com/ghassenTn/ChartForgeTK",
      githubUrl: "https://github.com/ghassenTn/ChartForgeTK"
    },
    {
      name: "clio-py",
      description: "A lightweight Python framework for self-adaptive reasoning with LLMs. Inspired by Microsoft's CLIO",
      language: "Python",
      stars: 0,
      updated: "Recently",
      topics: ["Python", "LLM", "AI", "Framework"],
      url: "#",
      githubUrl: "https://github.com/ghassenTn/clio-py"
    },
    {
      name: "Adaptive-Tool-Invocation-Framework-ATIF",
      description: "A framework designed to enhance the tool-calling capabilities of Large Language Models (LLMs)",
      language: "Python",
      stars: 0,
      updated: "Aug 8",
      topics: ["Python", "LLM", "AI", "Framework"],
      url: "#",
      githubUrl: "https://github.com/ghassenTn/Adaptive-Tool-Invocation-Framework-ATIF"
    },
    {
      name: "py-craft-studio",
      description: "TypeScript-based creative development environment",
      language: "TypeScript",
      stars: 0,
      updated: "Sep 1",
      topics: ["TypeScript", "Development", "Studio"],
      url: "#",
      githubUrl: "https://github.com/ghassenTn/py-craft-studio"
    }
  ];

  return (
    <section className="py-20 bg-slate-50 dark:bg-slate-800">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Featured Projects
            </h2>
            <p className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto">
              Explore my latest work and open-source contributions
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <Card 
                key={index} 
                className="group border-0 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 bg-white dark:bg-slate-900 overflow-hidden"
              >
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                          {project.name}
                        </h3>
                        {project.isPrivate && (
                          <Badge variant="secondary" className="text-xs">Private</Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-slate-500 dark:text-slate-400">
                        <div className="flex items-center gap-1">
                          <span className={`w-2 h-2 rounded-full ${
                            project.language === 'Python' ? 'bg-green-500' : 'bg-blue-500'
                          }`} />
                          {project.language}
                        </div>
                        {project.stars > 0 && (
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 fill-current text-yellow-500" />
                            {project.stars}
                          </div>
                        )}
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {project.updated}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                    {project.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-2">
                    {project.topics.map((topic, topicIndex) => (
                      <Badge 
                        key={topicIndex} 
                        variant="outline" 
                        className="text-xs px-2 py-1 border-slate-200 dark:border-slate-700 hover:border-blue-300 dark:hover:border-blue-600"
                      >
                        {topic}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="flex-1 gap-2 hover:bg-slate-100 dark:hover:bg-slate-800"
                      asChild
                    >
                      <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                        <Github className="w-3 h-3" />
                        Code
                      </a>
                    </Button>
                    {project.url !== "#" && (
                      <Button 
                        size="sm" 
                        className="flex-1 gap-2"
                        asChild
                      >
                        <a href={project.url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-3 h-3" />
                          Demo
                        </a>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button variant="outline" size="lg" className="gap-2">
              <Github className="w-4 h-4" />
              View All Projects on GitHub
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;