import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

const SkillsSection = () => {
  const skills = [
    { category: "Programming Languages", items: ["Python", "TypeScript", "JavaScript", "Java"] },
    { category: "Frameworks & Libraries", items: ["React", "Next.js", "Node.js", "Express", "PyTorch", "TensorFlow"] },
    { category: "Tools & Technologies", items: ["Git", "Docker", "AWS", "PostgreSQL", "MongoDB", "Redis"] },
    { category: "Development Tools", items: ["VS Code", "Jupyter", "VS Code", "GitHub Actions"] },
  ];

  const expertiseLevels = [
    { skill: "Python", level: 90 },
    { skill: "TypeScript", level: 85 },
    { skill: "JavaScript", level: 88 },
    { skill: "React", level: 92 },
    { skill: "Node.js", level: 80 },
    { skill: "Machine Learning", level: 75 },
  ];

  return (
    <section className="py-20 bg-white dark:bg-slate-900">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Technical Skills
            </h2>
            <p className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto">
              Expertise in modern web development, AI/ML, and data science technologies
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Skills Categories */}
            <div className="space-y-8">
              {skills.map((skillGroup, index) => (
                <Card key={index} className="border-0 shadow-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
                  <CardHeader>
                    <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                      {skillGroup.category}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-3">
                      {skillGroup.items.map((skill, skillIndex) => (
                        <Badge 
                          key={skillIndex} 
                          variant="secondary" 
                          className="text-sm px-3 py-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 hover:bg-blue-200 dark:hover:bg-blue-800 transition-colors"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Expertise Levels */}
            <div className="space-y-8">
              <Card className="border-0 shadow-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
                <CardHeader>
                  <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                    Expertise Levels
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {expertiseLevels.map((item, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
                          {item.skill}
                        </span>
                        <span className="text-sm text-slate-500 dark:text-slate-400">
                          {item.level}%
                        </span>
                      </div>
                      <Progress value={item.level} className="h-2 bg-slate-200 dark:bg-slate-700" />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;