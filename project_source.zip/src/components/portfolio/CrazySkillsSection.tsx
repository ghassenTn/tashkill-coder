import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useState, useEffect } from "react";
import { Brain, Code, Zap, Database, Palette, Rocket } from "lucide-react";

const CrazySkillsSection = () => {
  const [activeCategory, setActiveCategory] = useState(0);
  const [floatingIcons, setFloatingIcons] = useState<{ id: number; x: number; y: number; icon: any }[]>([]);
  const [particles, setParticles] = useState<{ id: number; x: number; y: number }[]>([]);

  useEffect(() => {
    // Create floating icons
    const createFloatingIcon = () => {
      const icons = [Brain, Code, Zap, Database, Palette, Rocket];
      const Icon = icons[Math.floor(Math.random() * icons.length)];
      const id = Date.now() + Math.random();
      const x = Math.random() * window.innerWidth;
      const y = Math.random() * window.innerHeight;
      
      setFloatingIcons(prev => [...prev.slice(-10), { id, x, y, icon: <Icon className="w-6 h-6 text-blue-400 opacity-50" /> }]);
    };

    const iconInterval = setInterval(createFloatingIcon, 3000);

    // Create particles
    const createParticle = () => {
      const id = Date.now() + Math.random();
      const x = Math.random() * window.innerWidth;
      const y = Math.random() * window.innerHeight;
      
      setParticles(prev => [...prev, { id, x, y }]);
    };

    const particleInterval = setInterval(createParticle, 150);

    // Auto rotate categories
    const categoryInterval = setInterval(() => {
      setActiveCategory(prev => (prev + 1) % 4);
    }, 5000);

    return () => {
      clearInterval(iconInterval);
      clearInterval(particleInterval);
      clearInterval(categoryInterval);
    };
  }, []);

  useEffect(() => {
    // Remove old particles
    if (particles.length > 30) {
      setParticles(prev => prev.slice(1));
    }

    // Remove old floating icons
    if (floatingIcons.length > 10) {
      setFloatingIcons(prev => prev.slice(1));
    }
  }, [particles, floatingIcons]);

  const skills = [
    { category: "Programming Languages", items: ["Python", "TypeScript", "JavaScript", "Java"] },
    { category: "Frameworks & Libraries", items: ["React", "Next.js", "Node.js", "Express", "PyTorch", "TensorFlow"] },
    { category: "Tools & Technologies", items: ["Git", "Docker", "AWS", "PostgreSQL", "MongoDB", "Redis"] },
    { category: "Development Tools", items: ["VS Code", "Jupyter", "VS Code", "GitHub Actions"] },
  ];

  const expertiseLevels = [
    { skill: "Python", level: 90 },
    { skill: "TypeScript", level: 85 },
    { skill: "JavaScript", level: 88 },
    { skill: "React", level: 92 },
    { skill: "Node.js", level: 80 },
    { skill: "Machine Learning", level: 75 },
  ];

  const skillIcons = {
    Python: "🐍",
    TypeScript: "📝",
    JavaScript: "🟨",
    Java: "☕",
    React: "⚛️",
    "Next.js": "🚀",
    "Node.js": "🟢",
    Express: "🚂",
    PyTorch: "🔥",
    TensorFlow: "🧠",
    Git: "🐙",
    Docker: "🐳",
    AWS: "☁️",
    PostgreSQL: "🐘",
    MongoDB: "🍃",
    Redis: "🔴",
    "VS Code": "💻",
    Jupyter: "📓",
    "GitHub Actions": "⚡"
  };

  return (
    <section className="py-20 bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 dark:from-slate-900 dark:via-purple-900 dark:to-blue-900 relative overflow-hidden">
      {/* Floating particles */}
      <AnimatePresence>
        {particles.map((particle) => (
          <motion.div
            key={particle.id}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ 
              scale: [0, 1, 0],
              opacity: [0, 1, 0],
              x: particle.x + (Math.random() - 0.5) * 50,
              y: particle.y + (Math.random() - 0.5) * 50
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 3, ease: "easeInOut" }}
            className="absolute pointer-events-none"
            style={{
              left: particle.x,
              top: particle.y,
            }}
          >
            <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-blue-400 rounded-full" />
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Floating icons */}
      {floatingIcons.map((floatingIcon) => (
        <motion.div
          key={floatingIcon.id}
          initial={{ y: 0, opacity: 0 }}
          animate={{ 
            y: -50,
            opacity: [0, 0.5, 0],
            x: floatingIcon.x + (Math.random() - 0.5) * 30
          }}
          exit={{ opacity: 0 }}
          transition={{ duration: 4, ease: "easeOut" }}
          className="absolute pointer-events-none z-0"
          style={{
            left: floatingIcon.x,
            top: floatingIcon.y,
          }}
        >
          {floatingIcon.icon}
        </motion.div>
      ))}

      {/* Animated background shapes */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute -top-20 -right-20 w-80 h-80 bg-purple-300 rounded-full opacity-20 blur-3xl"
          animate={{
            x: [0, 50, -50, 0],
            y: [0, -50, 50, 0],
            scale: [1, 1.2, 0.8, 1]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute -bottom-20 -left-20 w-96 h-96 bg-blue-300 rounded-full opacity-20 blur-3xl"
          animate={{
            x: [0, -50, 50, 0],
            y: [0, 50, -50, 0],
            scale: [1, 0.8, 1.2, 1]
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 2
          }}
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-6xl mx-auto">
          {/* Animated title */}
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.h2 
              className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-4"
              animate={{ 
                backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
                scale: [1, 1.05, 1]
              }}
              transition={{ 
                duration: 3, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
              style={{ 
                backgroundSize: "200% 200%",
                WebkitBackgroundClip: "text",
                backgroundClip: "text"
              }}
            >
              Technical Skills
            </motion.h2>
            <motion.p 
              className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto"
              animate={{ 
                opacity: [0.7, 1, 0.7]
              }}
              transition={{ 
                duration: 4, 
                repeat: Infinity,
                delay: 0.5
              }}
            >
              Expertise in modern web development, AI/ML, and data science technologies
            </motion.p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Skills Categories */}
            <div className="space-y-8">
              {skills.map((skillGroup, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  whileHover={{ 
                    scale: 1.02,
                    transition: { duration: 0.3 }
                  }}
                >
                  <Card className="border-0 shadow-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 hover:shadow-2xl transition-all duration-300">
                    <CardHeader>
                      <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                        <motion.div
                          animate={{ 
                            rotate: [0, 360, 0],
                            scale: [1, 1.2, 1]
                          }}
                          transition={{ 
                            duration: 2, 
                            repeat: Infinity,
                            delay: index * 0.2
                          }}
                        >
                          {skillGroup.category.includes("Languages") && "🌐"}
                          {skillGroup.category.includes("Frameworks") && "🔧"}
                          {skillGroup.category.includes("Tools") && "🛠️"}
                          {skillGroup.category.includes("Development") && "💻"}
                        </motion.div>
                        {skillGroup.category}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-3">
                        {skillGroup.items.map((skill, skillIndex) => (
                          <motion.div
                            key={skillIndex}
                            whileHover={{ 
                              scale: 1.1,
                              rotate: 5,
                              y: -2
                            }}
                            whileTap={{ scale: 0.9 }}
                          >
                            <Badge 
                              variant="secondary" 
                              className="text-sm px-3 py-1 bg-gradient-to-r from-blue-100 to-purple-100 text-blue-800 dark:from-blue-900 dark:to-purple-900 dark:text-blue-200 hover:from-blue-200 hover:to-purple-200 dark:hover:from-blue-800 dark:hover:to-purple-800 transition-all duration-300 cursor-pointer"
                            >
                              <span className="mr-1">{skillIcons[skill as keyof typeof skillIcons] || "⚡"}</span>
                              {skill}
                            </Badge>
                          </motion.div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Expertise Levels */}
            <div className="space-y-8">
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                <Card className="border-0 shadow-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900 hover:shadow-2xl transition-all duration-300">
                  <CardHeader>
                    <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      <motion.div
                        animate={{ 
                          y: [0, -5, 0],
                          rotate: [0, 5, -5, 0]
                        }}
                        transition={{ 
                          duration: 2, 
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      >
                        📊
                      </motion.div>
                      Expertise Levels
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {expertiseLevels.map((item, index) => (
                      <motion.div 
                        key={index} 
                        className="space-y-2"
                        initial={{ opacity: 0, x: 30 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, delay: index * 0.1 }}
                      >
                        <div className="flex justify-between items-center">
                          <motion.span 
                            className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-2"
                            whileHover={{ scale: 1.05 }}
                          >
                            {skillIcons[item.skill as keyof typeof skillIcons] || "🎯"}
                            {item.skill}
                          </motion.span>
                          <motion.span 
                            className="text-sm text-slate-500 dark:text-slate-400 font-bold"
                            animate={{ 
                              scale: [1, 1.1, 1],
                              color: ["#6b7280", "#3b82f6", "#6b7280"]
                            }}
                            transition={{ 
                              duration: 2, 
                              repeat: Infinity,
                              delay: index * 0.3
                            }}
                          >
                            {item.level}%
                          </motion.span>
                        </div>
                        <motion.div 
                          className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden"
                          whileHover={{ scale: 1.02 }}
                        >
                          <motion.div
                            className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: item.level + "%" }}
                            transition={{ duration: 1, delay: index * 0.2 }}
                            style={{ 
                              background: "linear-gradient(90deg, #3b82f6, #8b5cf6)"
                            }}
                          />
                        </motion.div>
                      </motion.div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CrazySkillsSection;