import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Mail, Github, Linkedin, Twitter, Globe, MessageCircle, Send } from "lucide-react";

const ContactSection = () => {
  const socialLinks = [
    { name: "GitHub", url: "https://github.com/ghassenTn", icon: <Github className="w-5 h-5" />, color: "hover:bg-gray-100 dark:hover:bg-gray-800" },
    { name: "ORCID", url: "https://orcid.org/0009-0007-4728-6033", icon: <Globe className="w-5 h-5" />, color: "hover:bg-blue-100 dark:hover:bg-blue-900" },
    { name: "Kaggle", url: "https://www.kaggle.com/patchgc", icon: <MessageCircle className="w-5 h-5" />, color: "hover:bg-orange-100 dark:hover:bg-orange-900" },
    { name: "Twitter", url: "https://twitter.com/ghassenTn", icon: <Twitter className="w-5 h-5" />, color: "hover:bg-blue-100 dark:hover:bg-blue-900" }
  ];

  const skills = [
    "Full Stack Development", "Python Programming", "TypeScript/JavaScript", 
    "AI/ML Engineering", "Open Source Contributing", "Data Science"
  ];

  return (
    <section className="py-20 bg-white dark:bg-slate-900">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Get In Touch
            </h2>
            <p className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto">
              Let's connect and collaborate on exciting projects
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div className="space-y-8">
              <Card className="border-0 shadow-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
                <CardHeader>
                  <CardTitle className="text-2xl font-semibold text-slate-900 dark:text-slate-100">
                    Contact Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center gap-4 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg">
                    <Mail className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                    <div>
                      <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Email</p>
                      <p className="text-slate-900 dark:text-slate-100">ghassen.qi.pi.ki.li.mi.ni.ji</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 p-4 bg-slate-100 dark:bg-slate-800 rounded-lg">
                    <MessageCircle className="w-6 h-6 text-green-600 dark:text-green-400" />
                    <div>
                      <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Location</p>
                      <p className="text-slate-900 dark:text-slate-100">Sfax, Tunisia</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
                      I'm interested in:
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {skills.map((skill, index) => (
                        <Badge 
                          key={index} 
                          variant="secondary" 
                          className="text-sm px-3 py-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Social Links */}
              <Card className="border-0 shadow-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
                <CardHeader>
                  <CardTitle className="text-xl font-semibold text-slate-900 dark:text-slate-100">
                    Connect With Me
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    {socialLinks.map((link, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        className={`justify-start gap-3 transition-all ${link.color}`}
                        asChild
                      >
                        <a href={link.url} target="_blank" rel="noopener noreferrer">
                          {link.icon}
                          <span className="font-medium">{link.name}</span>
                        </a>
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Contact Form */}
            <Card className="border-0 shadow-lg bg-gradient-to-br from-slate-50 to-white dark:from-slate-800 dark:to-slate-900">
              <CardHeader>
                <CardTitle className="text-2xl font-semibold text-slate-900 dark:text-slate-100">
                  Send a Message
                </CardTitle>
                <p className="text-slate-600 dark:text-slate-400">
                  Fill out the form below and I'll get back to you as soon as possible.
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700 dark:text-slate-300">
                      Name *
                    </label>
                    <Input placeholder="Your name" className="bg-white dark:bg-slate-800" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-slate-700 dark:text-slate-300">
                      Email *
                    </label>
                    <Input placeholder="your.email@example.com" className="bg-white dark:bg-slate-800" />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300">
                    Subject
                  </label>
                  <Input placeholder="What's this about?" className="bg-white dark:bg-slate-800" />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300">
                    Message *
                  </label>
                  <Textarea 
                    placeholder="Your message..." 
                    className="min-h-[120px] bg-white dark:bg-slate-800 resize-none"
                  />
                </div>
                
                <Button size="lg" className="w-full gap-2">
                  <Send className="w-4 h-4" />
                  Send Message
                </Button>
                
                <p className="text-xs text-slate-500 dark:text-slate-400 text-center">
                  I typically respond within 24 hours on business days.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;