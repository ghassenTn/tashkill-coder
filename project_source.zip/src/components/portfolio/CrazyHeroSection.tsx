import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Github, ExternalLink, MapPin, Clock, Sparkles, Zap, Heart, Rocket } from "lucide-react";
import AnimatedBackground from "./AnimatedBackground";

const CrazyHeroSection = () => {
  const [glitch, setGlitch] = useState(false);
  const [particles, setParticles] = useState<{ id: number; x: number; y: number; size: number }[]>([]);

  useEffect(() => {
    // Glitch effect
    const glitchInterval = setInterval(() => {
      setGlitch(true);
      setTimeout(() => setGlitch(false), 50);
    }, 3000);

    // Particles effect
    const createParticle = () => {
      const id = Date.now() + Math.random();
      const x = Math.random() * window.innerWidth;
      const y = window.innerHeight + 20;
      const size = Math.random() * 6 + 2;
      
      setParticles(prev => [...prev, { id, x, y, size }]);
    };

    const particleInterval = setInterval(createParticle, 200);

    return () => {
      clearInterval(glitchInterval);
      clearInterval(particleInterval);
    };
  }, []);

  useEffect(() => {
    // Animate particles
    if (particles.length > 0) {
      const timer = setTimeout(() => {
        setParticles(prev => prev.slice(1));
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [particles]);

  const floatingElements = [
    { icon: <Sparkles className="w-6 h-6 text-yellow-400" />, delay: 0 },
    { icon: <Zap className="w-8 h-8 text-blue-400" />, delay: 0.5 },
    { icon: <Heart className="w-5 h-5 text-red-400" />, delay: 1 },
    { icon: <Rocket className="w-7 h-7 text-purple-400" />, delay: 1.5 },
  ];

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <AnimatedBackground />
      
      {/* Floating particles */}
      <AnimatePresence>
        {particles.map((particle) => (
          <motion.div
            key={particle.id}
            initial={{ y: 0, opacity: 1 }}
            animate={{ 
              y: -window.innerHeight - 100,
              x: particle.x + (Math.random() - 0.5) * 100,
              opacity: 0
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 2, ease: "easeOut" }}
            className="absolute pointer-events-none"
            style={{
              left: particle.x,
              top: particle.y,
            }}
          >
            <div 
              className="rounded-full bg-gradient-to-r from-blue-500 to-purple-500 animate-pulse"
              style={{ width: particle.size, height: particle.size }}
            />
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Floating elements */}
      {floatingElements.map((element, index) => (
        <motion.div
          key={index}
          initial={{ x: 0, y: 0, rotate: 0 }}
          animate={{ 
            x: [0, 100, -50, 0],
            y: [0, -50, 30, 0],
            rotate: [0, 360, -180, 0]
          }}
          transition={{
            duration: 6 + index,
            repeat: Infinity,
            delay: element.delay,
            ease: "easeInOut"
          }}
          className="absolute pointer-events-none"
          style={{
            left: `${10 + index * 20}%`,
            top: `${20 + index * 15}%`,
            zIndex: 1,
          }}
        >
          {element.icon}
        </motion.div>
      ))}

      {/* Main content container */}
      <motion.div 
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="container mx-auto px-4 relative z-10"
      >
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left side - Hero content */}
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="space-y-8"
            >
              {/* Animated status badge */}
              <motion.div
                animate={{ 
                  scale: [1, 1.1, 1],
                  rotate: [0, 2, -2, 0]
                }}
                transition={{ 
                  duration: 2, 
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="inline-flex"
              >
                <Badge 
                  variant="secondary" 
                  className={`inline-flex items-center gap-2 px-3 py-1 ${
                    glitch ? "animate-pulse bg-red-500 text-white" : ""
                  }`}
                >
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <motion.span
                    animate={{ color: ["#10b981", "#3b82f6", "#8b5cf6", "#10b981"] }}
                    transition={{ duration: 3, repeat: Infinity }}
                  >
                    ACTIVE CODER
                  </motion.span>
                </Badge>
              </motion.div>
              
              {/* Animated name */}
              <motion.div className="space-y-4">
                <motion.h1 
                  className="text-5xl lg:text-7xl font-bold bg-gradient-to-r from-slate-900 to-slate-600 dark:from-slate-100 dark:to-slate-400 bg-clip-text text-transparent leading-tight"
                  animate={{ 
                    backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"]
                  }}
                  transition={{ 
                    duration: 3, 
                    repeat: Infinity,
                    ease: "linear"
                  }}
                  style={{ 
                    backgroundSize: "200% 200%",
                    WebkitBackgroundClip: "text",
                    backgroundClip: "text"
                  }}
                >
                  Ghassen Saidi
                </motion.h1>
                
                <motion.p 
                  className="text-xl lg:text-2xl text-slate-600 dark:text-slate-300"
                  animate={{ 
                    scale: [1, 1.02, 1],
                    x: [0, 5, -5, 0]
                  }}
                  transition={{ 
                    duration: 4, 
                    repeat: Infinity,
                    delay: 0.5,
                    ease: "easeInOut"
                  }}
                >
                  Full Stack Developer & AI Enthusiast
                </motion.p>
                
                <motion.p 
                  className="text-lg text-slate-500 dark:text-slate-400 max-w-2xl leading-relaxed"
                  animate={{ 
                    opacity: [0.8, 1, 0.8]
                  }}
                  transition={{ 
                    duration: 3, 
                    repeat: Infinity,
                    delay: 1
                  }}
                >
                  We are a grassroots movement dedicated to raising awareness about the Palestinian cause and advocating for the rights of the Palestinian people.
                </motion.p>
              </motion.div>
              
              {/* Animated buttons */}
              <motion.div 
                className="flex flex-wrap gap-4"
                animate={{ y: [0, -5, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <motion.div whileHover={{ scale: 1.05, rotate: 2 }} whileTap={{ scale: 0.95 }}>
                  <Button size="lg" className="gap-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                    <Github className="w-4 h-4" />
                    View GitHub
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05, rotate: -2 }} whileTap={{ scale: 0.95 }}>
                  <Button size="lg" variant="outline" className="gap-2 hover:bg-slate-100 dark:hover:bg-slate-800">
                    <ExternalLink className="w-4 h-4" />
                    View Profile
                  </Button>
                </motion.div>
              </motion.div>
              
              {/* Animated info */}
              <motion.div 
                className="flex flex-wrap gap-6 text-sm text-slate-600 dark:text-slate-400"
                animate={{ 
                  x: [0, 10, -10, 0]
                }}
                transition={{ 
                  duration: 5, 
                  repeat: Infinity,
                  delay: 1.5
                }}
              >
                <motion.div whileHover={{ scale: 1.1 }} className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Sfax, Tunisia
                </motion.div>
                <motion.div whileHover={{ scale: 1.1 }} className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  21:42 UTC -12:00
                </motion.div>
                <motion.div whileHover={{ scale: 1.1 }} className="flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  4 followers · 6 following
                </motion.div>
              </motion.div>
            </motion.div>
            
            {/* Right side - Profile card */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ duration: 1, delay: 0.4 }}
              whileHover={{ 
                scale: 1.05,
                rotateY: 5,
                transition: { duration: 0.3 }
              }}
              className="relative"
            >
              <motion.div
                animate={{ 
                  boxShadow: [
                    "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
                    "0 30px 60px -15px rgba(59, 130, 246, 0.3)",
                    "0 25px 50px -12px rgba(0, 0, 0, 0.25)"
                  ]
                }}
                transition={{ 
                  duration: 3, 
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Card className="relative overflow-hidden border-0 shadow-2xl bg-white/80 backdrop-blur-lg dark:bg-slate-900/80">
                  <CardContent className="p-8">
                    <div className="flex flex-col items-center space-y-6">
                      {/* Animated avatar */}
                      <motion.div
                        animate={{ 
                          rotate: [0, 5, -5, 0],
                          scale: [1, 1.05, 1]
                        }}
                        transition={{ 
                          duration: 4, 
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      >
                        <Avatar className="w-32 h-32 ring-4 ring-blue-500/20 dark:ring-blue-400/20">
                          <AvatarImage src="https://avatars.githubusercontent.com/u/placeholder" />
                          <AvatarFallback className="text-3xl font-bold bg-gradient-to-br from-blue-600 to-purple-600 text-white">
                            GS
                          </AvatarFallback>
                        </Avatar>
                      </motion.div>
                      
                      <div className="text-center space-y-2">
                        <h3 className="text-2xl font-bold">Ghassen Saidi</h3>
                        <p className="text-slate-600 dark:text-slate-300">@ghassenTn</p>
                        <p className="text-sm text-slate-500 dark:text-slate-400">he/him</p>
                      </div>
                      
                      <motion.div 
                        className="flex gap-4"
                        animate={{ 
                          x: [0, -10, 10, 0]
                        }}
                        transition={{ 
                          duration: 3, 
                          repeat: Infinity,
                          delay: 0.5
                        }}
                      >
                        <Badge variant="secondary" className="hover:scale-110 transition-transform cursor-pointer">Python</Badge>
                        <Badge variant="secondary" className="hover:scale-110 transition-transform cursor-pointer">TypeScript</Badge>
                        <Badge variant="secondary" className="hover:scale-110 transition-transform cursor-pointer">JavaScript</Badge>
                      </motion.div>
                      
                      <motion.div 
                        className="flex gap-4 text-sm text-slate-600 dark:text-slate-400"
                        animate={{ 
                          y: [0, -5, 0]
                        }}
                        transition={{ 
                          duration: 2, 
                          repeat: Infinity
                        }}
                      >
                        <motion.div whileHover={{ scale: 1.2 }} className="text-center">
                          <div className="font-bold text-lg">4</div>
                          <div>Followers</div>
                        </motion.div>
                        <motion.div whileHover={{ scale: 1.2 }} className="text-center">
                          <div className="font-bold text-lg">6</div>
                          <div>Following</div>
                        </motion.div>
                      </motion.div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </motion.div>
    </section>
  );
};

export default CrazyHeroSection;