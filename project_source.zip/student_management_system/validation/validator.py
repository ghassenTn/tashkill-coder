
class Validator:
    @staticmethod
    def validate_student_id(student_id, existing_ids=None):
        if not isinstance(student_id, int) or student_id <= 0:
            return False, "Student ID must be a positive integer."
        if existing_ids is not None and str(student_id) in existing_ids:
            return False, "Student with this ID already exists."
        return True, ""

    @staticmethod
    def validate_name(name):
        if not isinstance(name, str) or not name.strip():
            return False, "Name cannot be empty."
        return True, ""

    @staticmethod
    def validate_age(age):
        if not isinstance(age, int) or not (5 <= age <= 100):
            return False, "Age must be an integer between 5 and 100."
        return True, ""

    @staticmethod
    def validate_grade(grade):
        if not isinstance(grade, str) or not grade.strip():
            return False, "Grade cannot be empty."
        return True, ""

    @staticmethod
    def validate_contact_info(contact_info):
        # Contact info is optional, so empty string is allowed
        if not isinstance(contact_info, str):
            return False, "Contact information must be a string."
        return True, ""

    @staticmethod
    def validate_student_data(student_id, name, age, grade, contact_info, existing_ids=None):
        is_valid, message = Validator.validate_student_id(student_id, existing_ids)
        if not is_valid:
            return False, message
        is_valid, message = Validator.validate_name(name)
        if not is_valid:
            return False, message
        is_valid, message = Validator.validate_age(age)
        if not is_valid:
            return False, message
        is_valid, message = Validator.validate_grade(grade)
        if not is_valid:
            return False, message
        is_valid, message = Validator.validate_contact_info(contact_info)
        if not is_valid:
            return False, message
        return True, ""
