
import tkinter as tk
from tkinter import ttk, messagebox

class StudentManagementApp(tk.Tk):
    def __init__(self, data_manager, validator, search_module):
        super().__init__()
        self.title("Student Management System")
        self.geometry("900x600")

        self.data_manager = data_manager
        self.validator = validator
        self.search_module = search_module

        self._create_widgets()
        self._load_students_to_table()

    def _create_widgets(self):
        # Main Frame
        main_frame = ttk.Frame(self, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Input Frame
        input_frame = ttk.LabelFrame(main_frame, text="Student Information", padding="10")
        input_frame.pack(fill=tk.X, pady=10)

        self.labels = ["ID:", "Name:", "Age:", "Grade:", "Contact Info:"]
        self.entries = {}
        for i, label_text in enumerate(self.labels):
            label = ttk.Label(input_frame, text=label_text)
            label.grid(row=i, column=0, padx=5, pady=2, sticky=tk.W)
            entry = ttk.Entry(input_frame, width=40)
            entry.grid(row=i, column=1, padx=5, pady=2, sticky=tk.EW)
            self.entries[label_text.replace(":", "").strip().lower()] = entry

        # Buttons Frame
        button_frame = ttk.Frame(main_frame, padding="10")
        button_frame.pack(fill=tk.X, pady=5)

        ttk.Button(button_frame, text="Add Student", command=self._add_student).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="Update Student", command=self._update_student).grid(row=0, column=1, padx=5)
        ttk.Button(button_frame, text="Delete Student", command=self._delete_student).grid(row=0, column=2, padx=5)
        ttk.Button(button_frame, text="Clear Fields", command=self._clear_fields).grid(row=0, column=3, padx=5)

        # Search Frame
        search_frame = ttk.Frame(main_frame, padding="10")
        search_frame.pack(fill=tk.X, pady=5)

        ttk.Label(search_frame, text="Search:").grid(row=0, column=0, padx=5, sticky=tk.W)
        self.search_entry = ttk.Entry(search_frame, width=30)
        self.search_entry.grid(row=0, column=1, padx=5, sticky=tk.EW)
        self.search_entry.bind("<KeyRelease>", self._perform_search) # Live search
        ttk.Button(search_frame, text="Show All", command=self._load_students_to_table).grid(row=0, column=2, padx=5)

        # Treeview (Table) for displaying students
        self.tree = ttk.Treeview(main_frame, columns=("ID", "Name", "Age", "Grade", "Contact Info"), show="headings")
        self.tree.heading("ID", text="ID", command=lambda: self._sort_column("ID", False))
        self.tree.heading("Name", text="Name", command=lambda: self._sort_column("Name", False))
        self.tree.heading("Age", text="Age", command=lambda: self._sort_column("Age", False))
        self.tree.heading("Grade", text="Grade", command=lambda: self._sort_column("Grade", False))
        self.tree.heading("Contact Info", text="Contact Info", command=lambda: self._sort_column("Contact Info", False))

        self.tree.column("ID", width=50, anchor=tk.CENTER)
        self.tree.column("Name", width=150)
        self.tree.column("Age", width=50, anchor=tk.CENTER)
        self.tree.column("Grade", width=100)
        self.tree.column("Contact Info", width=200)

        self.tree.pack(fill=tk.BOTH, expand=True, pady=10)
        self.tree.bind('<<TreeviewSelect>>', self._on_tree_select)

        # Scrollbar for the Treeview
        scrollbar = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def _clear_fields(self):
        for entry in self.entries.values():
            entry.delete(0, tk.END)

    def _get_input_values(self):
        student_id_str = self.entries['id'].get().strip()
        name = self.entries['name'].get().strip()
        age_str = self.entries['age'].get().strip()
        grade = self.entries['grade'].get().strip()
        contact_info = self.entries['contact info'].get().strip()

        student_id = None
        age = None

        if student_id_str:
            try:
                student_id = int(student_id_str)
            except ValueError:
                pass # Will be caught by validator
        if age_str:
            try:
                age = int(age_str)
            except ValueError:
                pass # Will be caught by validator

        return student_id, name, age, grade, contact_info

    def _add_student(self):
        student_id, name, age, grade, contact_info = self._get_input_values()

        existing_ids = self.data_manager.students.keys()
        is_valid, message = self.validator.validate_student_data(
            student_id, name, age, grade, contact_info, existing_ids
        )

        if not is_valid:
            messagebox.showerror("Validation Error", message)
            return

        success, msg = self.data_manager.add_student(student_id, name, age, grade, contact_info)
        if success:
            messagebox.showinfo("Success", msg)
            self._clear_fields()
            self._load_students_to_table()
        else:
            messagebox.showerror("Error", msg)

    def _update_student(self):
        student_id, name, age, grade, contact_info = self._get_input_values()

        # For update, the ID must exist, but we don't check for unique ID creation
        # as it's an update on an existing one.
        # However, we need to ensure the ID field is not empty and is a valid integer.
        if not student_id:
            messagebox.showerror("Validation Error", "Student ID is required for updating.")
            return

        # Validate other fields. We pass None for existing_ids as we are updating an existing one.
        is_valid, message = self.validator.validate_student_data(
            student_id, name, age, grade, contact_info, existing_ids=None
        )
        if not is_valid:
            # If the error is about ID uniqueness, ignore it for update, unless it's a new invalid ID.
            if "ID already exists" in message:
                pass # This is fine for update operation as it's the existing ID
            elif "ID must be a positive integer" in message:
                messagebox.showerror("Validation Error", message)
                return
            else:
                messagebox.showerror("Validation Error", message)
                return

        success, msg = self.data_manager.update_student(student_id, name, age, grade, contact_info)
        if success:
            messagebox.showinfo("Success", msg)
            self._clear_fields()
            self._load_students_to_table()
        else:
            messagebox.showerror("Error", msg)

    def _delete_student(self):
        selected_item = self.tree.focus()
        if not selected_item:
            messagebox.showwarning("No Selection", "Please select a student to delete.")
            return

        student_id = self.tree.item(selected_item)['values'][0]
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete student ID: {student_id}?"):
            success, msg = self.data_manager.delete_student(student_id)
            if success:
                messagebox.showinfo("Success", msg)
                self._clear_fields()
                self._load_students_to_table()
            else:
                messagebox.showerror("Error", msg)

    def _load_students_to_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        students = self.data_manager.get_all_students()
        for student in students:
            self.tree.insert("", tk.END, values=(
                student['id'], student['name'], student['age'], student['grade'], student['contact_info']
            ))

    def _on_tree_select(self, event):
        selected_item = self.tree.focus()
        if selected_item:
            values = self.tree.item(selected_item)['values']
            self.entries['id'].delete(0, tk.END)
            self.entries['id'].insert(0, values[0])
            self.entries['name'].delete(0, tk.END)
            self.entries['name'].insert(0, values[1])
            self.entries['age'].delete(0, tk.END)
            self.entries['age'].insert(0, values[2])
            self.entries['grade'].delete(0, tk.END)
            self.entries['grade'].insert(0, values[3])
            self.entries['contact info'].delete(0, tk.END)
            self.entries['contact info'].insert(0, values[4])

    def _perform_search(self, event=None):
        query = self.search_entry.get()
        all_students = self.data_manager.get_all_students()
        filtered_students = self.search_module.search_students(all_students, query)

        for item in self.tree.get_children():
            self.tree.delete(item)

        for student in filtered_students:
            self.tree.insert("", tk.END, values=(
                student['id'], student['name'], student['age'], student['grade'], student['contact_info']
            ))

    def _sort_column(self, col, reverse):
        # Get all items from the treeview
        l = [(self.tree.set(k, col), k) for k in self.tree.get_children('')]
        
        # Determine the data type for sorting
        if col in ["ID", "Age"]:
            l.sort(key=lambda t: int(t[0]), reverse=reverse)
        else:
            l.sort(key=lambda t: t[0], reverse=reverse)

        # Rearrange items in sorted order
        for index, (val, k) in enumerate(l):
            self.tree.move(k, '', index)

        # Reverse sort order for next click
        self.tree.heading(col, command=lambda: self._sort_column(col, not reverse))




