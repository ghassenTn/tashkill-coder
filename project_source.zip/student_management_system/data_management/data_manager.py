
import json
import os

DATA_FILE = os.path.join(os.path.dirname(__file__), '../data/students.json')

class DataManager:
    def __init__(self):
        self.students = self._load_data()

    def _load_data(self):
        if not os.path.exists(DATA_FILE):
            return {}
        with open(DATA_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                return {}

    def _save_data(self):
        with open(DATA_FILE, 'w') as f:
            json.dump(self.students, f, indent=4)

    def add_student(self, student_id, name, age, grade, contact_info):
        if str(student_id) in self.students:
            return False, "Student with this ID already exists."
        self.students[str(student_id)] = {
            "name": name,
            "age": age,
            "grade": grade,
            "contact_info": contact_info
        }
        self._save_data()
        return True, "Student added successfully."

    def get_student(self, student_id):
        return self.students.get(str(student_id))

    def get_all_students(self):
        # Convert dictionary to a list of dictionaries with ID included
        all_students = []
        for student_id, details in self.students.items():
            student_data = {"id": student_id}
            student_data.update(details)
            all_students.append(student_data)
        return all_students

    def update_student(self, student_id, name, age, grade, contact_info):
        if str(student_id) not in self.students:
            return False, "Student not found."
        self.students[str(student_id)] = {
            "name": name,
            "age": age,
            "grade": grade,
            "contact_info": contact_info
        }
        self._save_data()
        return True, "Student updated successfully."

    def delete_student(self, student_id):
        if str(student_id) in self.students:
            del self.students[str(student_id)]
            self._save_data()
            return True, "Student deleted successfully."
        return False, "Student not found."
