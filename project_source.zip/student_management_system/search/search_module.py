
class SearchModule:
    @staticmethod
    def search_students(students, query):
        if not query:
            return students  # Return all students if query is empty

        query = str(query).lower()
        results = []
        for student in students:
            # Search by ID (exact match) or Name (partial, case-insensitive match)
            if str(student['id']).lower() == query or query in student['name'].lower():
                results.append(student)
        return results
