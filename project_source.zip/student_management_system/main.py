
from data_management.data_manager import DataManager
from validation.validator import Validator
from search.search_module import SearchModule
from gui.app_gui import StudentManagementApp

if __name__ == "__main__":
    data_manager = DataManager()
    validator = Validator()
    search_module = SearchModule()

    app = StudentManagementApp(data_manager, validator, search_module)
    app.mainloop()
